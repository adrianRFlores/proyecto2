<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="bon2.css">
</head>
<body>
<header>
	<a href="reglasort.php"><img src="logo.png" alt="logo" height="200"  /></a>
	
<h1 style="text-align: center;">Cuento</h1>
</header>
<nav>
<h1 align="center">Primer cuento</h1>	
<p>
<img src="c.png" alt="logo"  />
</p>
<a href="com.php"><button type="input">Comprobación</button></a>

</nav>
</body>

</html>