<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="bon2.css">
</head>
<body>
<header>
	<a href="reglasort.php"><img src="logo.png" alt="logo" height="200"  /></a>
	
<h1 style="text-align: center;">Comprobación lectora</h1>
</header>
<nav>
<h1 align="center">Responder:</h1>	
<p>
<img src="co.png" alt="logo"  width="620" />
</p>
<a href="#"><button type="input">Revisar</button></a>

</nav>
</body>

</html>