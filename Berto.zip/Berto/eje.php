<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="bon2.css">
</head>
<body>
<header>
	<a href="reglasort.php"><img src="logo.png" alt="logo" height="200"  /></a>
	
<h1 style="text-align: center;">Ejercicios de ortografía</h1>
</header>
<nav>
<h1 align="center">I. La mordida</h1>	
<p>
Ayer en la tarde, yo ________(encontrar: pasado) un perrito
que _______ (empezar: pasado) a seguirme.Yo ________ (caminar: pasado)
más rápido, pero él se ________(enojar: pasado)
y me (morder: pasado) la mano.
¿Qué se _______(deber: presente) hacer en estos casos?
</p>

<h1 align="center">II. La curación</h1>
<p>
Primero se ______(lavar: presente) la herida con agua y
jabón. Después se ______(poner: presente) una gasa esterilizada
y se (apretar: presente) fuerte la mordida hasta que
________(dejar: presente) de sangrar. Luego se ________(llevar: presente)
al perro al centro antirrábico o con el veterinario.
</p>
<h1 align="center">III. Las precauciones y el peligro</h1>
<p>
	Pero, si el perro ________(ser: presente) callejero, usted ________(pedir:
futuro) a otras personas que lo ________(ayudar: presente)
a agarrarlo, porque en el Centro Antirrábico lo ________(observar:
futuro) para ver si tiene rabia y ellos ________(decir: futuro)
al médico cuál es el estado de salud del perro. Así usted
________(saber: futuro) cuál es el tratamiento indicado.
</p>
<button type="input">Revisar</button>
</nav>
</body>

</html>